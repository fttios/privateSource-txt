#如何发布自己的开源框架到CocoaPods
##——在项目所在目录下执行* pod init * , 生成Podfile文件, 我们需要对其进行相应的配置。
在开发过程中，经常会使用到第三框架，我们通过一个pod install命令，很方便的就将第三方框架加到我们自己的项目中。
[用CocoaPods做iOS程序的依赖管理](http://blog.devtang.com/2014/05/25/use-cocoapod-to-manage-ios-lib-dependency/)

###在github创建仓库完成，需要将仓库检出到本地（截取网上的例子）
注意：LICENSE(许可证)文件不可缺少，否则检测spec文件时，会有警告

![](http://img.blog.csdn.net/20170118141659926?watermark/2/text/aHR0cDovL2Jsb2cuY3Nkbi5uZXQvdmJpcmRiZXN0/font/5a6L5L2T/fontsize/400/fill/I0JBQkFCMA==/dissolve/70/gravity/SouthEast)
###将写好开源框架/库的Demo或者Example放到Git仓库下，还要将要开源的文件夹也放入到git仓库中（该文件夹在后面会被用到）（截取网上的例子）

![](http://img.blog.csdn.net/20170118142333722?watermark/2/text/aHR0cDovL2Jsb2cuY3Nkbi5uZXQvdmJpcmRiZXN0/font/5a6L5L2T/fontsize/400/fill/I0JBQkFCMA==/dissolve/70/gravity/SouthEast)

###项目发布到github后，我们在工程根目录中初始化一个Podspec文件：创建自己项目的Podspec描述文件:
pod spec create ECGCustomAlertView

该命令将在本目录产生一个名为ECGCustomAlertView.podspec文件。用编辑器（命令行：vim ECGCustomAlertView.podspec）打开该文件，里面已经有非常丰富的说明文档。下面介绍如何声明第三方库的代码目录和资源目录，还有该第三方库所依赖ios核心框架和第三方库。这是我的podspec文件：
![](http://a1.qpic.cn/psb?/V12Sqxp908KBnU/.P8d0Z4PGDDWLXM*.4mmw5QYg0cOg7zphPPhq1epTJ8!/b/dGgBAAAAAAAA&bo=DgM.AA4DPgADCSw!&rf=viewer_4)
![](http://a1.qpic.cn/psb?/V12Sqxp908KBnU/c9NckaY5B9vwfXh6DsV.VeFLSytlQ20GdHD5r4*TF.I!/b/dGgBAAAAAAAA&bo=DQMXAA0DFwADACU!&rf=viewer_4)
![](http://a1.qpic.cn/psb?/V12Sqxp908KBnU/kDSttIKJOg*H2GDkHgKBZmBmenDaS0pLyZthAS0eG28!/b/dGgBAAAAAAAA&bo=CwMXAAsDFwADACU!&rf=viewer_4)
![](http://a1.qpic.cn/psb?/V12Sqxp908KBnU/bX3UXK3xUbsUc*grQ2Y2gqfujBuv0sDMvDG0jhi7XHU!/b/dGgBAAAAAAAA&bo=CwM*AAsDPwADACU!&rf=viewer_4)
![](http://a3.qpic.cn/psb?/V12Sqxp908KBnU/HFLp97jxEFD.eHS2OUP1qIJ8Z3oREhL9L2SRXV4B1AA!/b/dGcBAAAAAAAA&bo=CwMgAAsDIAADACU!&rf=viewer_4)
![](http://a1.qpic.cn/psb?/V12Sqxp908KBnU/72dhGa3CvZ2*CnDqa9WK0ix7Jxxv8urq1tn7CltMC6U!/b/dGgBAAAAAAAA&bo=DQMWAA0DFgADACU!&rf=viewer_4)
![](http://a1.qpic.cn/psb?/V12Sqxp908KBnU/0Jj*P4p2E.dnKTc8ixyTSsxelF1X6A9Ca*V*edtWZhg!/b/dGgBAAAAAAAA&bo=DAMbAAwDGwADACU!&rf=viewer_4)
s.name：名称，pod search 搜索的关键词,注意这里一定要和.podspec的名称一样,否则报错 s.version：版本号 s.ios.deployment_target:支持的pod最低版本 s.summary: 简介 s.homepage:项目主页地址 s.license:许可证 s.author:作者 s.social_media_url:社交网址,这里我写的微博默认是Twitter,如果你写Twitter的话,你的podspec发布成功后会@你 s.source:项目的地址 s.source_files:需要包含的源文件 s.resources: 资源文件 s.requires_arc: 是否支持ARC s.dependency：依赖库，不能依赖未发布的库，如 s.dependency = ‘AFNetworking’ s.dependency：依赖库，如有多个可以这样写。我这里是托管在github上,所以这里将地址copy过来就行了。

![](http://cc.cocimg.com/api/uploads/20160229/1456712205881497.png)

source_files:写法及含义建议大家写第一种或者第二种。

![](http://a3.qpic.cn/psb?/V12Sqxp908KBnU/PmZ4lTcOhNjRCYrLPMMLSYJLzVCuFSQJa4ZKhqKy*.M!/b/dGcBAAAAAAAA&bo=YAKxAGACsQADCSw!&rf=viewer_4)

"ECGCustomAlertView/*"

"ECGCustomAlertView/ECGCustomAlertView/*.{h,m}"

"ECGCustomAlertView/**/*.h"


    “*” 表示匹配所有文件
    “*.{h,m}” 表示匹配所有以.h和.m结尾的文件
    “**” 表示匹配所有子目录

###设置tag号，提交修改（注：只要spec文件被修改，就必须重新执行如下命令）
git commit -m "Release 1.0.1" (先提交当前修改)

git tag 1.0.1 (添加tag)

git push --tags (推送tag到远程)

git push origin master (推送到远程到代码仓库)


###提交之前先验证.podspec文件是否合法

pod spec lint ECGCustomAlertView.podspec

![](http://a2.qpic.cn/psb?/V12Sqxp908KBnU/mfdrTaltaUNbheev90J3G094rgTdJ.UIz0c61PSNlxM!/b/dGYBAAAAAAAA&bo=DAPFAAwDxQADCSw!&rf=viewer_4)

从错误信息中得到：我的项目编译不通过：ECGLoadsAlertViewController.h 类文件找不到，需要将项目错误的地方修改掉，如果显示这样的提示信息：
![](http://a1.qpic.cn/psb?/V12Sqxp908KBnU/UnckyyUXdTzwGDHBaKWVE93rCC1*Q*y8P62dh2FnruE!/b/dGgBAAAAAAAA&bo=BwNvAAcDbwADCSw!&rf=viewer_4)

那么就是已经配置成功，可以提交到cocoapods了，否则要将所有提示的error和warn修改掉。

###验证.podspec文件报错，解决方法
####先删除远程tag
git push origin :refs/tags/1.0.1
####修改spec文件（必须修改相应的version和source）
####重新执行-->设置tag号，提交修改的步骤
###podspec文件验证成功，通过trunk推送podspec文件
pod trunk push ECGCustomAlertView.podspec
####如果有如下提示，需要你用邮箱注册一个trunk
![](http://a1.qpic.cn/psb?/V12Sqxp908KBnU/73cx0GS.Du5jOQPVJtVG1*kVU6vxW6FK3sQqkgV6RnU!/b/dGgBAAAAAAAA&bo=DwO4AQ8DuAEDCSw!&rf=viewer_4)
####用邮箱注册trunk（建议：用github注册的邮箱地址为好，外加用户名-->gitub的用户名（我用邮箱用户名也通过了））
pod trunk register 邮箱地址 "用户名" --description="macbook pro"

之后会有一封带有验证链接的邮件发送到你输入的邮箱，点击验证后就可以回来终端继续提交操作了。

###提交到cocoapods
pod trunk push ECGCustomAlertView.podspec
####我碰到了个错误提示：
![](http://a1.qpic.cn/psb?/V12Sqxp908KBnU/WqlxDIhaBMUZOpoyDR88Br*e1TEqBulK93UA*YKUO5w!/b/dFYBAAAAAAAA&bo=EANyABADcgADCSw!&rf=viewer_4)
####网上查的解决方法：
[解决方案](http://www.sw33tcode.com/?p=31)

实质：If you get this error message:（如果你获得这个错误信息：）

![](http://a1.qpic.cn/psb?/V12Sqxp908KBnU/WUTGiei5lUmCsl.fbV7FJfScKNrOsZnmZdzbcZF7Lq8!/b/dGgBAAAAAAAA&bo=*AFCAPwBQgADACU!&rf=viewer_4)

You need to set and unset that rename limit:

![](http://a1.qpic.cn/psb?/V12Sqxp908KBnU/H5OzfwGaI7Kop8egNRai9O7z7ahFTZjgQuMCuiKyM0Q!/b/dGgBAAAAAAAA&bo=8wEyAPMBMgADACU!&rf=viewer_4)

git config merge.renameLimit 999999

git config --unset merge.renameLimit

然后继续提交到cocoapods，如果成功会出现：
![](http://a1.qpic.cn/psb?/V12Sqxp908KBnU/PY9r*T7v6C3genpYkRlKM3699dOYTmOB.6Tf5LvSoOM!/b/dGgBAAAAAAAA&bo=sQLhALEC4QADACU!&rf=viewer_4)

###Cocoapods: pod search无法搜索到类库的解决办法
####删除~/Library/Caches/CocoaPods目录下的search_index.json文件

    pod setup成功后会生成~/Library/Caches/CocoaPods/search_index.json文件。
    终端输入rm ~/Library/Caches/CocoaPods/search_index.json
    删除成功后再执行pod search
稍等片刻就会出现你所要搜的类库了。


###podspec文件更新方法

以后我们的库有新版本时，我们可以修改相应的version和source。

有时你可能会遇到这种情况：执行pod trunk push操作后发现podspec文件的某个地方写错了，想更新一下。对于这种情况，我们可能会先尝试着在把podspec文件push一次。但是如果你的代码版本号没变(podspec里的version自然也没变)就会提示push失败，即使你更改了podspec的其他地方，pod也会认为这两个文件是同一个。 我目前为止找不到trunk的相关update接口，所以只能顺水推舟，更新源代码版本号（如：1.1.1->1.1.2），重新push version tag，然后再执行pod trunk push操作。
####后来遇到的坑：
#####1.通过代码创建的podspec文件里面都是双引号，博主用的都是单引号，经测试，无影响，还有UIKIT等库和第三方库的引入，以及版本升级，这一部分已经放在这里；
#####2.发现一个问题，如果你在某个库中用了NSInteger，会报警告，原因是：typedef long NSInteger;类似这种情况的还有别的，如果遇到你可以替换成像这里应该是long，也可以选择忽略警告，比如：pod trunk push ScrollSliderView.podspec –allow-warnings；
#####3.有时候在push时会遇到这样的报错：[!] There was an error pushing a new version to trunk: Net::OpenTimeout 不要惊慌，仅仅是因为网络不好没有push成功，不妨再试一次。